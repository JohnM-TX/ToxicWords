import os, sys
MODEL_DB_ROOT = os.path.dirname(os.path.abspath(__file__))
