this script is used for translating non-english languages to english languages.
For the test set it requires a lot manual work.
