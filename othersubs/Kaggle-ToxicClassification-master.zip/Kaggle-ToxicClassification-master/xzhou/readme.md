plan:

1. tokenize
2. check stanford glove res, find frequent words that missing in glove
   if exist (and not too much), manully check
3. adapt word emb and LDA and other features
4. adapt tree model (lightgbm)
