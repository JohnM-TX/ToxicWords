numpy
scipy
scikit-learn
matplotlib
pandas
nltk
lightgbm
