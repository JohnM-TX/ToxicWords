#### Usage:
in the folder `src`
```
$ python main.py --train train.csv --test test.csv --config model.cfg
```
