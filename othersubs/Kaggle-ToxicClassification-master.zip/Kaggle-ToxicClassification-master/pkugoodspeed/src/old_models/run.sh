python single_label_run.py --train ../data/train_processed.csv --test ../data/train_processed.csv --config cfgs/cnn.cfg 
python single_label_run.py --train ../data/train_processed.csv --test ../data/train_processed.csv --config cfgs/rnn.cfg 
python single_label_run.py --train ../data/train_processed.csv --test ../data/train_processed.csv --config cfgs/rcnn.cfg 
